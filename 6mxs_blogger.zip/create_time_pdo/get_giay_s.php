<?php

date_default_timezone_set('Asia/Ho_Chi_Minh');

$total = 1240;
$count = file_get_contents("count.txt");

if ($count == $total) {
	echo "Hoàn thành";
	exit;
}

header("Refresh: 0;");

$dem = $count+1;

$timestamp = file_get_contents("giay.txt");
$thoigian = date("c", $timestamp);

$tep = fopen("list_giay.txt", "a+");
fwrite($tep, "$timestamp\n");
fclose($tep);


/*giay +10*/
$rand = mt_rand(10000, 12000);
$file = fopen("giay.txt", "w");
fwrite($file, $timestamp+$rand);
fclose($file);

// tang them +1 vao file count.txt
$file = fopen("count.txt", "w");
fwrite($file, $dem);
fclose($file);

// show
echo "$dem/$total";
//echo $data;
