<?php

$data = trim(file_get_contents('list_giay.txt'));

$giay = explode("\n", $data);

echo count($giay);

file_put_contents('giay_giay.txt', json_encode($giay));