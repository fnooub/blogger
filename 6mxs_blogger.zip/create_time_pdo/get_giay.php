<?php

date_default_timezone_set('Asia/Ho_Chi_Minh');

//mktime( $hour, $minute, $second, $month, $day, $year);

$timestamp = mktime(6,9,45,03,16,2019);
echo "Ngày: ". date("H:i:s d/m/Y", $timestamp) . "<br />";
echo "Timestamp: " . $timestamp;