<?php

echo date("c", "1566294459");