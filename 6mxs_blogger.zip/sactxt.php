<?php

$data = json_decode(file_get_contents('sactxt_data.json'), true);
$times = json_decode(file_get_contents('giay_giay.txt'), true);

foreach ($data as $key => &$dt) {
    $dt['time'] = $times[$key];
}

//echo date("c", time());

echo '<pre>';
print_r($data);
echo '</pre>';

// save blogger
file_put_contents('data.json', json_encode($data));


function myfilesize($size, $precision = 2) {
	static $units = array('B','KB','MB','GB','TB','PB','EB','ZB','YB');
	$step = 1024;
	$i = 0;
	while (($size / $step) > 0.9) {
		$size = $size / $step;
		$i++;
	}
	return round($size, $precision).$units[$i];
}