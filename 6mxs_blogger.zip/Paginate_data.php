<?php

include "Paginate.php";

$data = json_decode(file_get_contents('data/list_links.txt'), true);
$total = count($data);

$config['current_page'] = isset($_GET['trang']) ? $_GET['trang'] : 1;
$config['total_rows'] = $total;
$config['base_url'] = 'Paginate_data.php?trang=(:num)';
$config['per_page'] = 12;
$config['num_links'] = 7;
$config['prev_link'] = '&laquo; Trước';
$config['next_link'] = 'Sau &raquo;';

$paginate = new Paginate();
$paginate->initialize($config);

$data = $paginate->get_array($data);

foreach ($data as $row) {
	echo '<p>' . $row . '</p>';
}

echo $paginate->create_links();
