<?php

$data = file_get_contents('data.csv');

$datax = explode("\n", $data);

for ($i = 0; $i < (count($datax)-2); $i++) {
	$explode = explode(",", $datax[$i]);

	$datas[] = array(trim($explode[0]), trim($explode[1]), trim($explode[3]));
}

file_put_contents('datas_convert.txt', json_encode($datas));

//echo searchForId('15635.txt', $datas);
	

echo count($datas);
echo '<pre>';
print_r($datas);
echo '</pre>';

function searchForId($id, $array) {
	foreach ($array as $key => $val) {
		if ($val[1] === $id) {
			return $val[0];
		}
	}
	return null;
}
