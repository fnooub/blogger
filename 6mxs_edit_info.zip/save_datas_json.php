<?php

$datas = json_decode(file_get_contents('datas_convert.txt'), true);
$datas_chinese = json_decode(file_get_contents('datas_chinese.txt'), true);

foreach ($datas as $data) {
    $info = json_decode(file_get_contents('info/' . $data[1]));
    $gid_chinese = searchForId($data[1], $datas_chinese);
    $datax[] = array('tieude' => $info->tieude, 'mota' => $info->mota, 'count_chapter' => trim(file_get_contents('chapter/' . $data[1])), 'size' => $data[2], 'drive_id' => $data[0], 'drive_id_chinese' => $gid_chinese);
}

echo '<pre>';
print_r($datax);
echo '</pre>';

file_put_contents('sactxt_data.json', json_encode($datax));

function searchForId($id, $array) {
	foreach ($array as $key => $val) {
		if ($val[1] === $id) {
			return $val[0];
		}
	}
	return null;
}
