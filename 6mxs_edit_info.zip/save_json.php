<?php

$files = glob("info/*");
$ids = json_decode(file_get_contents('ids.txt'), true);

foreach ($files as $key => $file) {
    $info = json_decode(file_get_contents($file));
    $data[] = array('tieude' => $info->tieude, 'mota' => $info->mota, 'drive_id' => $ids[$key]);
}

echo '<pre>';
print_r($data);
echo '</pre>';
	
file_put_contents('data.json', json_encode($data));
