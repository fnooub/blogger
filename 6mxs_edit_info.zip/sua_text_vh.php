<?php

$files = glob("text/*");

foreach ($files as $file) {
	$filename = str_replace('text/', 'edit/', $file);
	// tach thong tin
	$text = str_replace('---Sactxt. blogspot. com---', '---Sactxt.blogspot.com---', file_get_contents($file));

	$text = preg_replace('/[\r\t]/', '', $text);
	$text = preg_replace( '/[\n]+/', "\n\n", $text );


	file_put_contents($filename, $text . "\n\nTruyện được tải miễn phí tại sactxt.blogspot.com truy cập ngay để xem những truyện sắc hay và hấp dẫn cập nhật liên tục.");
		
}