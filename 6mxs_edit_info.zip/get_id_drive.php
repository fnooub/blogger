<?php

$data = file_get_contents('data.csv');

$datax = explode("\n", $data);

for ($i = 0; $i < (count($datax)-2); $i++) {
	$explode = explode(",", $datax[$i]);

	$ids[] = trim($explode[0]);
}

file_put_contents('ids.txt', json_encode($ids));

echo '<pre>';
print_r($ids);
echo '</pre>';
