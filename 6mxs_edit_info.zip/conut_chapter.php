<?php

$files = glob("edit/*");

foreach ($files as $file) {
	$filename = str_replace('edit/', 'chapter/', $file);
	$count = substr_count(file_get_contents($file), "---Sactxt.blogspot.com---");
	file_put_contents($filename, ($count-1));
}