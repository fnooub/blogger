<?php

$files = glob("text/*");

foreach ($files as $file) {
	$filename = str_replace('text/', 'info/', $file);
	// tach thong tin
	preg_match('@---Sactxt. blogspot. com---(.+?)---Sactxt. blogspot. com---@si', file_get_contents($file), $info);
	$data_info = explode("\n", trim($info[1]));
	$info_save = array('tieude' => trim($data_info[0]), 'mota' => trim($data_info[2]));

	// save
	file_put_contents($filename, json_encode($info_save));
		
}